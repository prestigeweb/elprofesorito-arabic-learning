import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useLanguage } from "@/contexts/LanguageContext";

const TermsOfService = () => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-background font-arabic">
      <Header />
      <main className="pt-20">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl font-bold text-spanish-navy mb-8 text-center">
              {t('footer.legal.terms')}
            </h1>
            
            <div className="prose prose-lg max-w-none">
              <section className="mb-8">
                <h2 className="text-2xl font-semibold text-spanish-navy mb-4">
                  {t('terms.acceptance.title')}
                </h2>
                <p className="text-gray-700 leading-relaxed">
                  {t('terms.acceptance.content')}
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold text-spanish-navy mb-4">
                  {t('terms.services.title')}
                </h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  {t('terms.services.content')}
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>{t('terms.services.items.arabic')}</li>
                  <li>{t('terms.services.items.exam')}</li>
                  <li>{t('terms.services.items.materials')}</li>
                  <li>{t('terms.services.items.support')}</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold text-spanish-navy mb-4">
                  {t('terms.payment.title')}
                </h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  {t('terms.payment.content')}
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>{t('terms.payment.items.fees')}</li>
                  <li>{t('terms.payment.items.schedule')}</li>
                  <li>{t('terms.payment.items.refunds')}</li>
                  <li>{t('terms.payment.items.late')}</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold text-spanish-navy mb-4">
                  {t('terms.conduct.title')}
                </h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  {t('terms.conduct.content')}
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>{t('terms.conduct.items.respect')}</li>
                  <li>{t('terms.conduct.items.attendance')}</li>
                  <li>{t('terms.conduct.items.homework')}</li>
                  <li>{t('terms.conduct.items.communication')}</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold text-spanish-navy mb-4">
                  {t('terms.cancellation.title')}
                </h2>
                <p className="text-gray-700 leading-relaxed">
                  {t('terms.cancellation.content')}
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold text-spanish-navy mb-4">
                  {t('terms.liability.title')}
                </h2>
                <p className="text-gray-700 leading-relaxed">
                  {t('terms.liability.content')}
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold text-spanish-navy mb-4">
                  {t('terms.changes.title')}
                </h2>
                <p className="text-gray-700 leading-relaxed">
                  {t('terms.changes.content')}
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-semibold text-spanish-navy mb-4">
                  {t('terms.contact.title')}
                </h2>
                <p className="text-gray-700 leading-relaxed">
                  {t('terms.contact.content')}
                </p>
                <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                  <p className="text-gray-700">
                    <strong>Email:</strong> legal@elprofesoritoeg.com<br />
                    <strong>Phone:</strong> +20 100 123 4567<br />
                    <strong>Address:</strong> {t('contact.ways.address.value')}
                  </p>
                </div>
              </section>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default TermsOfService;
